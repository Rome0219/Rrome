package com.example.demo.entity;


    public class Entries {
        private int Entry_id;
        private String name;
        private String Bookdescription;

        public int getEntriesId()
        {
            return Entry_id;
        }

        public String getEntriesName()
        {
            return name;
        }

        public String getBookdescript()
        {
            return  Bookdescription;
        }

        public void setEntryId(int ent_id)
        {
            Entry_id = ent_id;
        }

        public void setEntryName(String entryName)
        {
            name = entryName;
        }

        public void setBookdescript(String BookDescrip)
        {
            Bookdescription = BookDescrip;
        }


    }

