package com.example.demo.repository;

import com.example.demo.entity.Entries;
import org.springframework.stereotype.Repository;
import java.util.Iterator;

import java.util.ArrayList;
import java.util.List;

@Repository

public class EntriesRepository
{
    private final List<Entries> list = new ArrayList<Entries>();
    public List<Entries> getAllEntries()
    {
        return list;
    }






    public Entries findByEntriesId(int entId)
    {
        for (int i = 0; i < list.size(); i++)
        {
            Entries entries = list.get(i);
            if (entries.getEntriesId() == entId) {
                return list.get(i); // Return the student at the actual index
            }
        }
        return null;
    }




    public void deleteByEntryId(int Ent_id)
    {
        Iterator<Entries> iterator = list.iterator();
        while (iterator.hasNext()) {
            Entries entries = iterator.next();
            if (entries.getEntriesId() == Ent_id)
            {
                iterator.remove();

            }
        }
    }






    public Entries updateStudent(int studId, Entries entries)
    {
        for (int i = 0; i < list.size(); i++)
        {
            Entries existingEntry = list.get(i);
            if (existingEntry.getEntriesId() == studId) {
                // Update the existing Entry at the actual index
                existingEntry.setEntryId(entries.getEntriesId());
                existingEntry.setEntryName(entries.getEntriesName());
                existingEntry.setBookdescript(entries.getBookdescript());
                return existingEntry;
            }
        }
        return null; // Return null if no student with the given Stud_id is found
    }



    public Entries saveEntry(Entries entries)
    {
        Entries s = new Entries();
        s.setEntryId(entries.getEntriesId());
        s.setEntryName(entries.getEntriesName());
        s.setBookdescript(entries.getBookdescript());
        list.add(s);
        return s;
    }






}
