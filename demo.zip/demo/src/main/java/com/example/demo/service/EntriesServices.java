package com.example.demo.service;

import com.example.demo.entity.Entries;
import com.example.demo.entity.Entries;
import com.example.demo.repository.EntriesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EntriesServices
{
    @Autowired
    private EntriesRepository entriesRepository;
    public List<Entries> getAllStudents()
    {
        return entriesRepository.getAllEntries();
    }

    public Entries findByStudentId(int Entries_id)
    {
        return entriesRepository.findByEntriesId(Entries_id);
    }

    public Entries saveEntry(Entries entries)
    {
        return entriesRepository.saveEntry(entries);
    }

    public void deleteByStudentId(int Entries_id)
    {
        entriesRepository.deleteByEntryId(Entries_id);
    }


    public Entries updateStudent(int Entries_id, Entries entries)
    {
        return entriesRepository.updateStudent(Entries_id, entries);
    }

}
